const themeToggle = document.getElementById('theme-toggle');
const body = document.body;

themeToggle.addEventListener('click', () => {
    if (body.getAttribute('data-theme') === 'dark') {
        body.removeAttribute('data-theme');
        themeToggle.textContent = '🌙';
    } else {
        body.setAttribute('data-theme', 'dark');
        themeToggle.textContent = '☀️';
    }
});
const filterBtn = document.getElementById('filter-toggle');
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('overlay');

filterBtn.addEventListener('click', () => {
    sidebar.classList.add('active');
    overlay.classList.add('active');
});
overlay.addEventListener('click', () => {
    sidebar.classList.remove('active');
    overlay.classList.remove('active');
});